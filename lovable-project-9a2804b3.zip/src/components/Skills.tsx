import { motion } from "framer-motion";
import {
  Cpu, Layers, Zap, Database, Shield, GitBranch,
  Swords, Boxes, Crosshair, Sparkles, Network, Wand2,
  Gamepad2, Server, Code2, MousePointerClick,
} from "lucide-react";

const skills = [
  { icon: Swords, name: "Combat Systems", desc: "Hitboxes, animations, ragdolls, knockback physics" },
  { icon: Crosshair, name: "Gun Frameworks", desc: "Recoil, hitscan, projectiles, attachments, reload logic" },
  { icon: Boxes, name: "Inventory Systems", desc: "Drag & drop, stacking, hotbars, persistent saves" },
  { icon: Wand2, name: "Emote & Animation", desc: "Radial menus, blending, replicated playback" },
  { icon: Layers, name: "Modular Frameworks", desc: "Reusable systems for abilities, items and stats" },
  { icon: Sparkles, name: "VFX & Feedback", desc: "Particles, screen shake, juicy game-feel polish" },
  { icon: Database, name: "DataStores", desc: "Player saves, leaderboards, persistent progression" },
  { icon: Shield, name: "Anti-Exploit", desc: "Server-authoritative checks and remote validation" },
  { icon: Network, name: "Networking", desc: "RemoteEvents, RemoteFunctions, lag compensation" },
  { icon: Server, name: "Server Architecture", desc: "Services, controllers, single-script frameworks" },
  { icon: GitBranch, name: "Clean Code", desc: "OOP patterns, modular Luau, scalable structure" },
  { icon: MousePointerClick, name: "UI/UX Design", desc: "Animated interfaces, responsive scaling, polish" },
  { icon: Cpu, name: "Optimization", desc: "Streaming, instance pooling, memory profiling" },
  { icon: Gamepad2, name: "Gameplay Design", desc: "Mechanics tuning, player feedback loops" },
  { icon: Code2, name: "Luau Mastery", desc: "Typed Luau, metatables, advanced patterns" },
  { icon: Zap, name: "Rapid Prototyping", desc: "Idea → playable system in record time" },
];

const Skills = () => {
  return (
    <section id="skills" className="py-28 relative overflow-hidden">
      {/* ambient glows */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] rounded-full bg-primary/10 blur-[140px] animate-float pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] rounded-full bg-accent/10 blur-[140px] animate-float pointer-events-none" style={{ animationDelay: "3s" }} />

      <div className="container relative">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <p className="font-mono text-sm text-accent mb-3">// skills</p>
          <h2 className="font-display font-bold text-4xl md:text-5xl mb-4">
            Complex <span className="text-gradient">Systems</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            The systems and patterns I work with to build polished Roblox experiences.
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5 max-w-7xl mx-auto">
          {skills.map((s, i) => (
            <motion.div
              key={s.name}
              initial={{ opacity: 0, y: 30, scale: 0.92 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.45, delay: (i % 4) * 0.07, ease: [0.22, 1, 0.36, 1] }}
              whileHover={{ y: -6, transition: { duration: 0.25 } }}
              className="group relative glass-card neon-border rounded-xl p-6 overflow-hidden"
            >
              {/* radial flare */}
              <div className="absolute -top-12 -right-12 w-40 h-40 rounded-full bg-gradient-to-br from-primary/30 to-accent/30 blur-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

              {/* scan line */}
              <div className="pointer-events-none absolute inset-0 overflow-hidden opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="absolute inset-x-0 h-1/3 bg-gradient-to-b from-transparent via-primary/15 to-transparent animate-scan" />
              </div>

              <div className="relative">
                <motion.div
                  whileHover={{ rotate: 360, scale: 1.1 }}
                  transition={{ duration: 0.6, ease: "easeOut" }}
                  className="w-12 h-12 rounded-lg bg-secondary flex items-center justify-center mb-4 group-hover:bg-gradient-to-br group-hover:from-primary group-hover:to-accent transition-all group-hover:shadow-[0_0_25px_hsl(var(--primary)/0.6)]"
                >
                  <s.icon className="w-5 h-5 text-accent group-hover:text-primary-foreground transition-colors" />
                </motion.div>
                <h3 className="font-display font-semibold text-lg mb-1.5 group-hover:text-gradient transition-all">
                  {s.name}
                </h3>
                <p className="text-muted-foreground text-sm">{s.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;
