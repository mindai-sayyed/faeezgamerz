import { motion } from "framer-motion";
import { Play } from "lucide-react";

const projects = [
  {
    id: "WAef5NGUNwg",
    title: "Featured Showcase",
    desc: "A highlight reel of recent Roblox systems and gameplay experiments built in Studio.",
    tags: ["Roblox", "Lua", "Showcase"],
  },
  {
    id: "KMWA9b2GU4A",
    title: "Inventory System",
    desc: "Dynamic inventory with drag & drop slots, hotbar, item stacking, and persistent saves.",
    tags: ["Roblox", "Luau", "UI"],
  },
  {
    id: "JuxIYeJ2II8",
    title: "Gun Framework",
    desc: "Modular gunplay framework — recoil, hitscan & projectiles, attachments, and reload logic.",
    tags: ["Roblox", "Framework", "Guns"],
  },
  {
    id: "BICnlyn8IAc",
    title: "Emote System",
    desc: "Smooth player emote system with animation blending, radial menu, and synced playback.",
    tags: ["Roblox", "Animation", "UI"],
  },
  {
    id: "evuj3S6QjNo",
    title: "Combat System",
    desc: "Custom melee combat with hitboxes, ragdolls, knockback physics, and responsive feedback.",
    tags: ["Roblox", "Combat", "Physics"],
  },
];

const Projects = () => {
  return (
    <section id="projects" className="py-28 relative">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <p className="font-mono text-sm text-accent mb-3">// projects</p>
          <h2 className="font-display font-bold text-4xl md:text-5xl mb-4">
            Featured <span className="text-gradient">Work</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            A selection of Roblox systems and prototypes I've built and showcased.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((p, i) => (
            <motion.article
              key={p.id}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: (i % 3) * 0.1 }}
              whileHover={{ y: -8, scale: 1.015 }}
              className="glass-card neon-border rounded-2xl overflow-hidden group flex flex-col relative"
            >
              {/* gradient flare on hover */}
              <div className="pointer-events-none absolute -top-20 -right-20 w-60 h-60 rounded-full bg-gradient-to-br from-primary/20 to-accent/20 blur-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

              <div className="relative aspect-video bg-secondary overflow-hidden">
                <iframe
                  className="absolute inset-0 w-full h-full"
                  src={`https://www.youtube.com/embed/${p.id}`}
                  title={p.title}
                  loading="lazy"
                  allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
                {/* scanline overlay */}
                <div className="pointer-events-none absolute inset-0 overflow-hidden opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="absolute inset-x-0 h-1/3 bg-gradient-to-b from-transparent via-primary/20 to-transparent animate-scan" />
                </div>
              </div>
              <div className="p-6 flex-1 flex flex-col">
                <div className="flex items-center gap-2 mb-3">
                  <Play className="w-4 h-4 text-accent" />
                  <span className="font-mono text-xs text-muted-foreground">project_{String(i + 1).padStart(2, "0")}</span>
                </div>
                <h3 className="font-display font-semibold text-xl mb-2 group-hover:text-gradient transition-all">
                  {p.title}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed mb-4 flex-1">{p.desc}</p>
                <div className="flex flex-wrap gap-2">
                  {p.tags.map((t) => (
                    <motion.span
                      key={t}
                      whileHover={{ y: -2, scale: 1.05 }}
                      className="text-xs font-mono px-2.5 py-1 rounded-full bg-primary/10 text-primary border border-primary/20 cursor-default"
                    >
                      {t}
                    </motion.span>
                  ))}
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;
