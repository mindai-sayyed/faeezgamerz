import { motion } from "framer-motion";
import { Zap, Brain, Target, Rocket, Shield, Heart } from "lucide-react";

const points = [
  {
    icon: Brain,
    title: "Systems Thinker",
    desc: "I don't just script features — I architect modular frameworks that scale, stay readable, and survive future updates.",
  },
  {
    icon: Zap,
    title: "Performance Obsessed",
    desc: "Every RemoteEvent, loop, and hitbox is profiled. Smooth 60fps gameplay isn't a nice-to-have — it's the baseline.",
  },
  {
    icon: Shield,
    title: "Server-Authoritative Mindset",
    desc: "Exploit-resistant by default. Sanity checks, rate limits, and trust-no-client logic are built in from day one.",
  },
  {
    icon: Target,
    title: "Polish Over Hype",
    desc: "I ship realistic, working systems — combat, guns, inventories, emotes — not flashy demos that break under load.",
  },
  {
    icon: Rocket,
    title: "Fast Iteration",
    desc: "Quick prototypes, clear communication, and clean handoffs. You'll see progress, not silence.",
  },
  {
    icon: Heart,
    title: "Genuine Passion",
    desc: "I play the games I build. Player experience drives every design choice I make.",
  },
];

const Different = () => {
  return (
    <section id="different" className="py-28 relative overflow-hidden">
      {/* Background accents */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 -left-32 w-80 h-80 rounded-full bg-primary/10 blur-3xl animate-float" />
        <div className="absolute bottom-1/4 -right-32 w-80 h-80 rounded-full bg-accent/10 blur-3xl animate-float" style={{ animationDelay: "2s" }} />
      </div>

      <div className="container relative">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="max-w-3xl mx-auto text-center mb-16"
        >
          <p className="font-mono text-sm text-accent mb-3">// what_sets_me_apart</p>
          <h2 className="font-display font-bold text-4xl md:text-5xl mb-6">
            What Makes Me <span className="text-gradient">Different</span>
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            Plenty of devs can write a script. Here's what I bring to the table beyond just code.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {points.map((p, i) => (
            <motion.div
              key={p.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              whileHover={{ y: -8, scale: 1.02 }}
              className="glass-card neon-border rounded-2xl p-6 group relative overflow-hidden"
            >
              {/* Hover gradient flare */}
              <div className="absolute inset-0 bg-gradient-to-br from-primary/0 via-accent/0 to-primary/0 group-hover:from-primary/10 group-hover:via-transparent group-hover:to-accent/10 transition-all duration-500 pointer-events-none" />

              {/* Number badge */}
              <div className="absolute top-4 right-4 font-mono text-xs text-muted-foreground/50">
                0{i + 1}
              </div>

              <motion.div
                whileHover={{ rotate: 360, scale: 1.1 }}
                transition={{ duration: 0.6 }}
                className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center mb-4 relative z-10"
              >
                <p.icon className="w-6 h-6 text-accent" />
              </motion.div>

              <h3 className="font-display font-semibold text-xl mb-2 relative z-10 group-hover:text-gradient transition-all">
                {p.title}
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed relative z-10">
                {p.desc}
              </p>

              {/* Bottom glow line */}
              <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Different;
