import { motion } from "framer-motion";
import { Gamepad2, Code, Sparkles } from "lucide-react";

const cards = [
  { icon: Gamepad2, title: "Game Mechanics", desc: "Designing engaging gameplay loops, combat systems, and progression mechanics." },
  { icon: Code, title: "Lua Scripting", desc: "Writing clean, performant scripts using Roblox Studio and Luau." },
  { icon: Sparkles, title: "Always Learning", desc: "Exploring new tech, frameworks, and creative ways to push Roblox further." },
];

const About = () => {
  return (
    <section id="about" className="py-28 relative">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="max-w-3xl mx-auto text-center mb-16"
        >
          <p className="font-mono text-sm text-accent mb-3">// about_me</p>
          <h2 className="font-display font-bold text-4xl md:text-5xl mb-6">
            Building worlds, <span className="text-gradient">one script at a time</span>
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            I'm a Roblox developer and programmer passionate about turning ideas into playable
            experiences. I focus on scripting, game mechanics, and learning new tech to keep
            pushing the limits of what I can build.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {cards.map((c, i) => (
            <motion.div
              key={c.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: i * 0.15 }}
              whileHover={{ y: -6 }}
              className="glass-card neon-border rounded-2xl p-6 group"
            >
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center mb-4 group-hover:from-primary/30 group-hover:to-accent/30 transition-colors">
                <c.icon className="w-6 h-6 text-accent" />
              </div>
              <h3 className="font-display font-semibold text-xl mb-2">{c.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{c.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;
